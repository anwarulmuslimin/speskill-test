<?php

namespace App\Models;

use CodeIgniter\Model;

class NarcissisticModel extends Model
{
    // protected $table = "table";
    // protected $primaryKey = "id";
    // protected $returnType = "object";
    // protected $useTimestamps = true;
    // protected $allowedFields = ['id', 'nama'];

    public function proccess($number)
    {
        $sum = 0;
        $temp = $number;
        $totalDigits = strlen($number);

        while ($number != 0) {
            $r = $number % 10;
            $sum = $sum + pow($r, $totalDigits);
            $number = floor($number / 10);
        }

        if ($sum == $temp) {
            $hasil =  "true";
        } else {
            $hasil =  "false";
        }
        return $hasil;
    }
}
