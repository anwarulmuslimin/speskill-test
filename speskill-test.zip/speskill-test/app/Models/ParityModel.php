<?php

namespace App\Models;

use CodeIgniter\Model;

class ParityModel extends Model
{
    // protected $table = "table";
    // protected $primaryKey = "id";
    // protected $returnType = "object";
    // protected $useTimestamps = true;
    // protected $allowedFields = ['id', 'nama'];

    public function proccess($data)
    {
        $odds = [];
        $evens = [];
        foreach ($data as $item) {
            if ($item % 2) array_push($odds, $item);
            else array_push($evens, $item);
        }
        $result = count($evens) === 1 ? $evens[0] : $odds[0];
        return $result;
    }
}
