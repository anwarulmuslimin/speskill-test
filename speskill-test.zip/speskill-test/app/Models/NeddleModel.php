<?php

namespace App\Models;

use CodeIgniter\Model;

class NeddleModel extends Model
{
    // protected $table = "table";
    // protected $primaryKey = "id";
    // protected $returnType = "object";
    // protected $useTimestamps = true;
    // protected $allowedFields = ['id', 'nama'];

    static function proccess($string, $find)
    {
        $da = json_encode($string);
        $replace  = str_replace('"', '', $da);
        $array = explode(",", $replace);
        $total = count($array);
        $result = 0;
        for ($a = 0; $a < $total; $a++) {
            if ($find == $array[$a]) {
                ++$result;
            }
        }

        return $result;
    }
}
