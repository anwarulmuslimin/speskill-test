<?php

namespace App\Models;

use CodeIgniter\Model;

class BlueModel extends Model
{
    // protected $table = "table";
    // protected $primaryKey = "id";
    // protected $returnType = "object";
    // protected $useTimestamps = true;
    // protected $allowedFields = ['id', 'nama'];

    public function proccess($string, $find)
    {

        $da = json_encode($string);
        $replace  = str_replace('"', '', $da);
        $array = explode(",", $replace);
        $total = count($array);
        $hasil = '';
        for ($a = 0; $a < $total; $a++) {
            if ($find != $array[$a]) {
                $hasil .= $array[$a];
            }
        }

        return $hasil;
    }
}
