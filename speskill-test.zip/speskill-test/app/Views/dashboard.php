<?= $this->include('template/header') ?>
<?= $this->renderSection('content') ?>
<?= $this->include('template/footer') ?>

