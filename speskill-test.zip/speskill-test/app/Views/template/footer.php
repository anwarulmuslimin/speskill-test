<footer class="jumbotron jumbotron-fluid mt-5 mb-0">
    <div class="container text-center">Copyright &copy <?= Date('Y') ?> CI News</div>
</footer>

<!-- Jquery dan Bootsrap JS -->
<script src="<?= base_url('js/jquery.min.js') ?>"></script>
<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>