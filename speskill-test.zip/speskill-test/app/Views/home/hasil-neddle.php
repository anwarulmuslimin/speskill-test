<?= $this->extend('dashboard') ?>
<?= $this->section('content') ?>
<header class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h1"> RESULT NEEDLE IN THE HAYSTACK</h1>
            </div>
        </div>
    </div>
</header>

<div class="container">
    <div class="row">
        <div class="col-md-12 my-2 card">
            <div class="card-body">

                <div class="form-group">
                    <label>Data Array:</label>
                    <input readonly class="form-control" value="<?php echo $product ?>" />
                </div>

                <div class="form-group">
                    <label>Saearch:</label>
                    <input readonly class="form-control" value="<?php echo $search ?>" />
                </div>

                <div class="form-group">
                    <label>Result:</label>
                    <input readonly class="form-control" value="<?php echo $result ?>" />
                </div>


            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>