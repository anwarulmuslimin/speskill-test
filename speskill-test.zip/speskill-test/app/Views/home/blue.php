<?= $this->extend('dashboard') ?>
<?= $this->section('content') ?>
<header class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h1">THE BLUE OCEAN REVERSE</h1>
            </div>
        </div>
    </div>
</header>

<div class="container">
    <div class="row">
        <div class="col-md-12 my-2 card">
            <div class="card-body">
                <form action="<?php echo base_url('blue-save') ?>" method="post">

                    <div class="form-group">
                        <label>Data Array:</label>
                        <input type="text" name="data_array" class="form-control" placeholder="Data Array" />
                    </div>
                    <div class="form-group">
                        <label>Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Search" />
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>