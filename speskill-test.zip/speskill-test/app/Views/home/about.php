<?= $this->extend('dashboard') ?>
<?= $this->section('content') ?>
<header class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h1">NARCISSISTIC NUMBER</h1>
            </div>
        </div>
    </div>
</header>

<div class="container">
    <div class="row">
        <div class="col-md-12 my-2 card">
            <div class="card-body">
                <form action="<?php echo base_url('narsistic-save') ?>" method="post">

                    <div class="form-group">
                        <label>Number:</label>
                        <input type="number" name="number" class="form-control" placeholder="Number" />
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>