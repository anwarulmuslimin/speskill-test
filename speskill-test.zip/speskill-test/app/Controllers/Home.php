<?php

namespace App\Controllers;

use App\Models\BlueModel;
use App\Models\NarcissisticModel;
use App\Models\NeddleModel;
use App\Models\ParityModel;

class Home extends BaseController
{

    protected $narcissistic;
    protected $neddle;
    protected $blue;
    protected $parity;

    function __construct()
    {
        $this->narcissistic     = new NarcissisticModel();
        $this->parity           = new ParityModel();
        $this->neddle           = new NeddleModel();
        $this->blue             = new BlueModel();
    }

    public function index()
    {
        return view('home/index');
    }

    public function about()
    {
        return view("home/about");
    }

    public function contact()
    {
        return view("home/contact");
    }

    public function faqs()
    {
        return view("home/faqs");
    }


    public function blue()
    {
        return view("home/blue");
    }

    public function save_narsistic()
    {
        $number = $this->request->getVar('number');

        $result = $this->narcissistic->proccess($number);

        return view('home/hasil-narsistic', array('product' => $number, 'result' => $result));
    }

    public function save_parity()
    {
        $parity = $this->request->getVar('parity');

        $result = $this->parity->proccess($parity);

        return view('home/hasil-parity', array('product' => $parity, 'result' => $result));
    }


    public function save_neddle()
    {
        $data_array = $this->request->getVar('data_array');
        $search = $this->request->getVar('search');

        $result = $this->neddle->proccess($data_array, $search);

        return view('home/hasil-neddle', array('product' => $data_array, 'search' => $search, 'result' => $result));
    }

    public function save_blue()
    {
        $data_array = $this->request->getVar('data_array');
        $search = $this->request->getVar('search');


        $result = $this->blue->proccess($data_array, $search);

        return view('home/hasil-blue', array('product' => $data_array, 'search' => $search, 'result' => $result));
    }
}
